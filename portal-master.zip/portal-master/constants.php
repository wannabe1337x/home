<?php 
define('ENTITY_PATH', './entity/');
define('CONTROLLERS_PATH', './controllers/');
define('VIEWS_PATH', './views/');
define('ADMIN_DIR', './admin/');
define('MOD_DIR', './modcp/');
define('CACHE_DIR', './cache/');
?>